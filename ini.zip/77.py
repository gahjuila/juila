

def menu():		
    print("=====================================")		
    print("=           MENU SELENIUM SOCKS5            =")		
    print("=====================================")		
    print("1. selenium")		
    print("0. Keluar")		
    print("\n")		
    menu = input("Masukkan menu pilihan Anda : ")		
    if menu == "1":		
        selenium()		
    elif menu == "0":		
        exit()		
    else:		
        print("Menu yang Anda masukkan salah!")		
        back_to_menu()		
def back_to_menu():		
    print("\n")		
    input("Tekan Enter untuk kembali...")		
    menu()		
def selenium():
    from selenium import webdriver		
    from selenium.webdriver.chrome.options import Options		
    from selenium.webdriver import ActionChains		
    from selenium.webdriver.common.keys import Keys		
    from selenium.webdriver.support.ui import WebDriverWait		
    from selenium.webdriver.common.action_chains import ActionChains		
    from selenium.webdriver.common.by import By		
    from selenium.webdriver.support import expected_conditions as EC		
    from selenium.webdriver.common.by import By		
    from time import sleep
    from capsolver_extension_python import Capsolver
    import string		
    import random		
    import copy		
    import sys		
    import subprocess		
    import zipfile
    import capsolver
    from config import mail61	
    from config import mail62	
    from config import mail63	
    from config import mail64	
    from config import mail65	
    from config import mail66	
    from config import mail67	
    from config import mail68	
    from config import mail69	
    from config import mail70	
    from config import password

    options = webdriver.ChromeOptions()		
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-cache")
    options.add_argument("--disable-notifications")
    options.add_argument("--window-size=800,900")
    options.add_argument(Capsolver(api_key="CAP-A72C395BE645D68EBE0406435F2AD7B0").load())
    options.add_extension('2captcha.zip')
    driver = webdriver.Chrome(options=options)


    
    driver.get("chrome://settings/performance")
    sleep(3)
    #print('Pilih:')		
    #print('1. google')		
    #print('0. kembali')		
    #alamat1 = input('Masukkan pilihan Anda: ')		
    #if alamat1 == '1':		
       #google = 'https://google.com'		
    #elif alamat1 == "0":		
       #menu()		
    #else:		
        #print("Menu yang Anda masukkan salah!")		
        #back_to_menu()		
    #driver.implicitly_wait(1200) # seconds		
    #driver.get(google)		
    #sleep(1)		
    print('Pilih:')		
    print('1. colab')		
    print('0. kembali')		
    alamat1 = input('Masukkan pilihan Anda: ')		
    if alamat1 == '1':		
       colab = 'https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE&hl=in'		
    elif alamat1 == "0":		
       menu()		
    else:		
        print("Menu yang Anda masukkan salah!")		
        back_to_menu()		
    driver.implicitly_wait(1200) # seconds		
    driver.get(colab)		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail61)
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()		
    sleep(2)		

    #next mail62
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail62)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail63
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail63)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail64
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail64)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail65
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail65)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail66
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail66)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail67
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail67)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail68
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail68)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail69
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail69)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #next mail610
    driver.implicitly_wait(300) # seconds
    driver.get("https://accounts.google.com/AddSession?service=accountsettings&continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue&ec=GAlAwAE")
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierId"]').send_keys(mail70)
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="identifierNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="password"]/div[1]/div/div[1]/input').send_keys('Jakarta123')
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="passwordNext"]/div/button/span').click()
    sleep(1)
    driver.find_element(by=By.XPATH, value='//*[@id="confirm"]').click()
    sleep(2)

    #question1 = input("Klik Enter For Run Colab..")

    #akun pertama tab satu		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1F95GRawuTUUTdVZe2x4fU-MFFEENCbEz?usp=sharing")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun kedua tab satu		
    driver.execute_script("window.open('about:blank', 'fourthtab');")		
    driver.switch_to.window("fourthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1P8yYXbb8HDsXNC9pTWBuC4shubnlYrxC?usp=sharing&authuser=1")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun ketiga tab satu		
    driver.execute_script("window.open('about:blank', 'seventhtab');")		
    driver.switch_to.window("seventhtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1lYgYE-hTseOb5C38hgzDInk11gI5By2k?usp=sharing&authuser=2")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun keempat tab satu		
    driver.execute_script("window.open('about:blank', 'tenthtab');")		
    driver.switch_to.window("tenthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1FOpXv4QZVCbHPQECbpyux9JdxhQvJBpA?usp=sharing&authuser=3")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun kelima tab satu		
    driver.execute_script("window.open('about:blank', 'thirteenthtab');")		
    driver.switch_to.window("thirteenthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1wnXNQcdtnpjAxlXjbhmhNkvPaM1olzYG?usp=sharing&authuser=4")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun keenam tab satu		
    driver.execute_script("window.open('about:blank', 'sixteenthtab');")		
    driver.switch_to.window("sixteenthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1F95GRawuTUUTdVZe2x4fU-MFFEENCbEz?usp=sharing&authuser=5")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun ketujuh tab satu		
    driver.execute_script("window.open('about:blank', 'nineteenthtab');")		
    driver.switch_to.window("nineteenthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1P8yYXbb8HDsXNC9pTWBuC4shubnlYrxC?usp=sharing&authuser=6")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun kedelapan tab satu		
    driver.execute_script("window.open('about:blank', 'twenty-secondtab');")		
    driver.switch_to.window("twenty-secondtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1lYgYE-hTseOb5C38hgzDInk11gI5By2k?usp=sharing&authuser=7")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun kesembilan tab satu		
    driver.execute_script("window.open('about:blank', 'twenty-fifthtab');")		
    driver.switch_to.window("twenty-fifthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1FOpXv4QZVCbHPQECbpyux9JdxhQvJBpA?usp=sharing&authuser=8")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)		
    #akun kesepuluh tab satu		
    driver.execute_script("window.open('about:blank', 'twenty-eighthtab');")		
    driver.switch_to.window("twenty-eighthtab")		
    driver.implicitly_wait(1200) # seconds		
    driver.get("https://colab.research.google.com/drive/1wnXNQcdtnpjAxlXjbhmhNkvPaM1olzYG?usp=sharing&authuser=9")		
    driver.implicitly_wait(20) # seconds		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='//colab-run-button').click()		
    sleep(1)		
    driver.find_element(by=By.XPATH, value='/html/body/mwc-dialog/mwc-button[2]').click()		
    sleep(5)
    back_to_menu()




    
if __name__ == "__main__":		
    while True:		
        menu()		
